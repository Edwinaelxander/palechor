﻿namespace Minimarket
{
    partial class UPD_Proveedor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.textBox_CIUDAD = new System.Windows.Forms.TextBox();
            this.textBox_DEP = new System.Windows.Forms.TextBox();
            this.textBox_NOM = new System.Windows.Forms.TextBox();
            this.textBox_RZ = new System.Windows.Forms.TextBox();
            this.textBox_TEL = new System.Windows.Forms.TextBox();
            this.textBox_EMAIL = new System.Windows.Forms.TextBox();
            this.textBox_NIT = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.nitDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.razonSocialDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telefonoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.correoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomeclaturaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ciudadDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.departamentoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.proveedorBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.Consultar = new System.Windows.Forms.Button();
            this.Actualizar = new System.Windows.Forms.Button();
            this.Enviar = new System.Windows.Forms.Button();
            this.ELIMINAR = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.proveedorBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox_CIUDAD
            // 
            this.textBox_CIUDAD.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox_CIUDAD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_CIUDAD.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_CIUDAD.Location = new System.Drawing.Point(1115, 251);
            this.textBox_CIUDAD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_CIUDAD.Name = "textBox_CIUDAD";
            this.textBox_CIUDAD.Size = new System.Drawing.Size(415, 47);
            this.textBox_CIUDAD.TabIndex = 31;
            // 
            // textBox_DEP
            // 
            this.textBox_DEP.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox_DEP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_DEP.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_DEP.Location = new System.Drawing.Point(1115, 48);
            this.textBox_DEP.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_DEP.Name = "textBox_DEP";
            this.textBox_DEP.Size = new System.Drawing.Size(415, 47);
            this.textBox_DEP.TabIndex = 30;
            // 
            // textBox_NOM
            // 
            this.textBox_NOM.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox_NOM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_NOM.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_NOM.Location = new System.Drawing.Point(1115, 149);
            this.textBox_NOM.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_NOM.Name = "textBox_NOM";
            this.textBox_NOM.Size = new System.Drawing.Size(415, 47);
            this.textBox_NOM.TabIndex = 29;
            // 
            // textBox_RZ
            // 
            this.textBox_RZ.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox_RZ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_RZ.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_RZ.Location = new System.Drawing.Point(261, 122);
            this.textBox_RZ.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_RZ.Name = "textBox_RZ";
            this.textBox_RZ.Size = new System.Drawing.Size(415, 47);
            this.textBox_RZ.TabIndex = 28;
            // 
            // textBox_TEL
            // 
            this.textBox_TEL.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox_TEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_TEL.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_TEL.Location = new System.Drawing.Point(261, 190);
            this.textBox_TEL.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_TEL.Name = "textBox_TEL";
            this.textBox_TEL.Size = new System.Drawing.Size(415, 47);
            this.textBox_TEL.TabIndex = 27;
            // 
            // textBox_EMAIL
            // 
            this.textBox_EMAIL.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox_EMAIL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_EMAIL.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_EMAIL.Location = new System.Drawing.Point(261, 260);
            this.textBox_EMAIL.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_EMAIL.Name = "textBox_EMAIL";
            this.textBox_EMAIL.Size = new System.Drawing.Size(415, 47);
            this.textBox_EMAIL.TabIndex = 26;
            // 
            // textBox_NIT
            // 
            this.textBox_NIT.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox_NIT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_NIT.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_NIT.Location = new System.Drawing.Point(261, 48);
            this.textBox_NIT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_NIT.Name = "textBox_NIT";
            this.textBox_NIT.Size = new System.Drawing.Size(415, 47);
            this.textBox_NIT.TabIndex = 25;
            this.textBox_NIT.TextChanged += new System.EventHandler(this.textBox_NIT_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Bernard MT Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(811, 53);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(207, 36);
            this.label6.TabIndex = 24;
            this.label6.Text = "DEPARTAMENTO :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bernard MT Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(913, 256);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 36);
            this.label5.TabIndex = 23;
            this.label5.Text = "CIUDAD :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bernard MT Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(832, 154);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(186, 36);
            this.label4.TabIndex = 22;
            this.label4.Text = "NOMECLATURA :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Bernard MT Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(25, 267);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(119, 36);
            this.label7.TabIndex = 21;
            this.label7.Text = "CORREO :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bernard MT Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(25, 194);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(139, 36);
            this.label3.TabIndex = 20;
            this.label3.Text = "TELEFONO :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bernard MT Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(25, 126);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(184, 36);
            this.label2.TabIndex = 19;
            this.label2.Text = "RAZON SOCIAL :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bernard MT Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 36);
            this.label1.TabIndex = 18;
            this.label1.Text = "NIT :";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nitDataGridViewTextBoxColumn,
            this.razonSocialDataGridViewTextBoxColumn,
            this.telefonoDataGridViewTextBoxColumn,
            this.correoDataGridViewTextBoxColumn,
            this.nomeclaturaDataGridViewTextBoxColumn,
            this.ciudadDataGridViewTextBoxColumn,
            this.departamentoDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.proveedorBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(31, 350);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1239, 345);
            this.dataGridView1.TabIndex = 32;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // nitDataGridViewTextBoxColumn
            // 
            this.nitDataGridViewTextBoxColumn.DataPropertyName = "Nit";
            this.nitDataGridViewTextBoxColumn.HeaderText = "Nit";
            this.nitDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nitDataGridViewTextBoxColumn.Name = "nitDataGridViewTextBoxColumn";
            this.nitDataGridViewTextBoxColumn.Width = 125;
            // 
            // razonSocialDataGridViewTextBoxColumn
            // 
            this.razonSocialDataGridViewTextBoxColumn.DataPropertyName = "RazonSocial";
            this.razonSocialDataGridViewTextBoxColumn.HeaderText = "RazonSocial";
            this.razonSocialDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.razonSocialDataGridViewTextBoxColumn.Name = "razonSocialDataGridViewTextBoxColumn";
            this.razonSocialDataGridViewTextBoxColumn.Width = 125;
            // 
            // telefonoDataGridViewTextBoxColumn
            // 
            this.telefonoDataGridViewTextBoxColumn.DataPropertyName = "Telefono";
            this.telefonoDataGridViewTextBoxColumn.HeaderText = "Telefono";
            this.telefonoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.telefonoDataGridViewTextBoxColumn.Name = "telefonoDataGridViewTextBoxColumn";
            this.telefonoDataGridViewTextBoxColumn.Width = 125;
            // 
            // correoDataGridViewTextBoxColumn
            // 
            this.correoDataGridViewTextBoxColumn.DataPropertyName = "Correo";
            this.correoDataGridViewTextBoxColumn.HeaderText = "Correo";
            this.correoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.correoDataGridViewTextBoxColumn.Name = "correoDataGridViewTextBoxColumn";
            this.correoDataGridViewTextBoxColumn.Width = 125;
            // 
            // nomeclaturaDataGridViewTextBoxColumn
            // 
            this.nomeclaturaDataGridViewTextBoxColumn.DataPropertyName = "Nomeclaturas";
            this.nomeclaturaDataGridViewTextBoxColumn.HeaderText = "Nomeclaturas";
            this.nomeclaturaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nomeclaturaDataGridViewTextBoxColumn.Name = "nomeclaturaDataGridViewTextBoxColumn";
            this.nomeclaturaDataGridViewTextBoxColumn.Width = 125;
            // 
            // ciudadDataGridViewTextBoxColumn
            // 
            this.ciudadDataGridViewTextBoxColumn.DataPropertyName = "Ciudad";
            this.ciudadDataGridViewTextBoxColumn.HeaderText = "Ciudad";
            this.ciudadDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.ciudadDataGridViewTextBoxColumn.Name = "ciudadDataGridViewTextBoxColumn";
            this.ciudadDataGridViewTextBoxColumn.Width = 125;
            // 
            // departamentoDataGridViewTextBoxColumn
            // 
            this.departamentoDataGridViewTextBoxColumn.DataPropertyName = "Departamento";
            this.departamentoDataGridViewTextBoxColumn.HeaderText = "Departamento";
            this.departamentoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.departamentoDataGridViewTextBoxColumn.Name = "departamentoDataGridViewTextBoxColumn";
            this.departamentoDataGridViewTextBoxColumn.Width = 125;
            // 
            // proveedorBindingSource
            // 
            this.proveedorBindingSource.DataSource = typeof(CL_CapaEntidades.Proveedor);
            // 
            // Consultar
            // 
            this.Consultar.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Consultar.Location = new System.Drawing.Point(1335, 350);
            this.Consultar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Consultar.Name = "Consultar";
            this.Consultar.Size = new System.Drawing.Size(196, 66);
            this.Consultar.TabIndex = 33;
            this.Consultar.Text = "CONSULTAR";
            this.Consultar.UseVisualStyleBackColor = true;
            this.Consultar.Click += new System.EventHandler(this.Consultar_Click);
            // 
            // Actualizar
            // 
            this.Actualizar.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Actualizar.Location = new System.Drawing.Point(1335, 437);
            this.Actualizar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Actualizar.Name = "Actualizar";
            this.Actualizar.Size = new System.Drawing.Size(196, 66);
            this.Actualizar.TabIndex = 34;
            this.Actualizar.Text = "ACTUALIZAR";
            this.Actualizar.UseVisualStyleBackColor = true;
            this.Actualizar.Click += new System.EventHandler(this.Actualizar_Click);
            // 
            // Enviar
            // 
            this.Enviar.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Enviar.Location = new System.Drawing.Point(1335, 628);
            this.Enviar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Enviar.Name = "Enviar";
            this.Enviar.Size = new System.Drawing.Size(196, 66);
            this.Enviar.TabIndex = 35;
            this.Enviar.Text = "ENVIAR";
            this.Enviar.UseVisualStyleBackColor = true;
            this.Enviar.Click += new System.EventHandler(this.Enviar_Click);
            // 
            // ELIMINAR
            // 
            this.ELIMINAR.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ELIMINAR.Location = new System.Drawing.Point(1335, 530);
            this.ELIMINAR.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ELIMINAR.Name = "ELIMINAR";
            this.ELIMINAR.Size = new System.Drawing.Size(196, 66);
            this.ELIMINAR.TabIndex = 37;
            this.ELIMINAR.Text = "ELIMINAR";
            this.ELIMINAR.UseVisualStyleBackColor = true;
            // 
            // UPD_Proveedor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1632, 812);
            this.Controls.Add(this.ELIMINAR);
            this.Controls.Add(this.Enviar);
            this.Controls.Add(this.Actualizar);
            this.Controls.Add(this.Consultar);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.textBox_CIUDAD);
            this.Controls.Add(this.textBox_DEP);
            this.Controls.Add(this.textBox_NOM);
            this.Controls.Add(this.textBox_RZ);
            this.Controls.Add(this.textBox_TEL);
            this.Controls.Add(this.textBox_EMAIL);
            this.Controls.Add(this.textBox_NIT);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "UPD_Proveedor";
            this.Text = "UPD_Proveedor";
            this.Load += new System.EventHandler(this.UPD_Proveedor_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.proveedorBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_CIUDAD;
        private System.Windows.Forms.TextBox textBox_DEP;
        private System.Windows.Forms.TextBox textBox_NOM;
        private System.Windows.Forms.TextBox textBox_RZ;
        private System.Windows.Forms.TextBox textBox_TEL;
        private System.Windows.Forms.TextBox textBox_EMAIL;
        private System.Windows.Forms.TextBox textBox_NIT;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource proveedorBindingSource;
        private System.Windows.Forms.Button Consultar;
        private System.Windows.Forms.Button Actualizar;
        private System.Windows.Forms.Button Enviar;
        private System.Windows.Forms.DataGridViewTextBoxColumn nitDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn razonSocialDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telefonoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn correoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomeclaturaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ciudadDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn departamentoDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button ELIMINAR;
    }
}