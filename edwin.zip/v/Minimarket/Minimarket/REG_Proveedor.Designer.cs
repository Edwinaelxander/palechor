﻿namespace Minimarket
{
    partial class REG_Proveedor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_NIT = new System.Windows.Forms.TextBox();
            this.textBox_EMAIL = new System.Windows.Forms.TextBox();
            this.textBox_TEL = new System.Windows.Forms.TextBox();
            this.textBox_RZ = new System.Windows.Forms.TextBox();
            this.textBox_NOM = new System.Windows.Forms.TextBox();
            this.textBox_DEP = new System.Windows.Forms.TextBox();
            this.textBox_CIUDAD = new System.Windows.Forms.TextBox();
            this.Registrar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bernard MT Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(160, 103);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 36);
            this.label1.TabIndex = 1;
            this.label1.Text = "NIT :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bernard MT Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(160, 176);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(184, 36);
            this.label2.TabIndex = 2;
            this.label2.Text = "RAZON SOCIAL :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bernard MT Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(160, 247);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(139, 36);
            this.label3.TabIndex = 3;
            this.label3.Text = "TELEFONO :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Bernard MT Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(160, 322);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(119, 36);
            this.label7.TabIndex = 7;
            this.label7.Text = "CORREO :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bernard MT Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(160, 390);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(186, 36);
            this.label4.TabIndex = 8;
            this.label4.Text = "NOMECLATURA :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bernard MT Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(160, 455);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 36);
            this.label5.TabIndex = 9;
            this.label5.Text = "CIUDAD :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Bernard MT Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(160, 521);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(207, 36);
            this.label6.TabIndex = 10;
            this.label6.Text = "DEPARTAMENTO :";
            // 
            // textBox_NIT
            // 
            this.textBox_NIT.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox_NIT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_NIT.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_NIT.Location = new System.Drawing.Point(483, 100);
            this.textBox_NIT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_NIT.Name = "textBox_NIT";
            this.textBox_NIT.Size = new System.Drawing.Size(415, 47);
            this.textBox_NIT.TabIndex = 11;
            // 
            // textBox_EMAIL
            // 
            this.textBox_EMAIL.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox_EMAIL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_EMAIL.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_EMAIL.Location = new System.Drawing.Point(483, 319);
            this.textBox_EMAIL.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_EMAIL.Name = "textBox_EMAIL";
            this.textBox_EMAIL.Size = new System.Drawing.Size(415, 47);
            this.textBox_EMAIL.TabIndex = 12;
            // 
            // textBox_TEL
            // 
            this.textBox_TEL.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox_TEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_TEL.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_TEL.Location = new System.Drawing.Point(483, 242);
            this.textBox_TEL.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_TEL.Name = "textBox_TEL";
            this.textBox_TEL.Size = new System.Drawing.Size(415, 47);
            this.textBox_TEL.TabIndex = 13;
            // 
            // textBox_RZ
            // 
            this.textBox_RZ.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox_RZ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_RZ.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_RZ.Location = new System.Drawing.Point(483, 172);
            this.textBox_RZ.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_RZ.Name = "textBox_RZ";
            this.textBox_RZ.Size = new System.Drawing.Size(415, 47);
            this.textBox_RZ.TabIndex = 14;
            // 
            // textBox_NOM
            // 
            this.textBox_NOM.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox_NOM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_NOM.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_NOM.Location = new System.Drawing.Point(483, 386);
            this.textBox_NOM.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_NOM.Name = "textBox_NOM";
            this.textBox_NOM.Size = new System.Drawing.Size(415, 47);
            this.textBox_NOM.TabIndex = 15;
            // 
            // textBox_DEP
            // 
            this.textBox_DEP.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox_DEP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_DEP.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_DEP.Location = new System.Drawing.Point(483, 517);
            this.textBox_DEP.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_DEP.Name = "textBox_DEP";
            this.textBox_DEP.Size = new System.Drawing.Size(415, 47);
            this.textBox_DEP.TabIndex = 16;
            // 
            // textBox_CIUDAD
            // 
            this.textBox_CIUDAD.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox_CIUDAD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_CIUDAD.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_CIUDAD.Location = new System.Drawing.Point(483, 452);
            this.textBox_CIUDAD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_CIUDAD.Name = "textBox_CIUDAD";
            this.textBox_CIUDAD.Size = new System.Drawing.Size(415, 47);
            this.textBox_CIUDAD.TabIndex = 17;
            // 
            // Registrar
            // 
            this.Registrar.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Registrar.Location = new System.Drawing.Point(1060, 359);
            this.Registrar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Registrar.Name = "Registrar";
            this.Registrar.Size = new System.Drawing.Size(196, 66);
            this.Registrar.TabIndex = 22;
            this.Registrar.Text = "REGISTRAR";
            this.Registrar.UseVisualStyleBackColor = true;
            this.Registrar.Click += new System.EventHandler(this.Registrar_Click);
            // 
            // REG_Proveedor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1632, 812);
            this.Controls.Add(this.Registrar);
            this.Controls.Add(this.textBox_CIUDAD);
            this.Controls.Add(this.textBox_DEP);
            this.Controls.Add(this.textBox_NOM);
            this.Controls.Add(this.textBox_RZ);
            this.Controls.Add(this.textBox_TEL);
            this.Controls.Add(this.textBox_EMAIL);
            this.Controls.Add(this.textBox_NIT);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "REG_Proveedor";
            this.Text = "REG_Proveedor";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_NIT;
        private System.Windows.Forms.TextBox textBox_EMAIL;
        private System.Windows.Forms.TextBox textBox_TEL;
        private System.Windows.Forms.TextBox textBox_RZ;
        private System.Windows.Forms.TextBox textBox_NOM;
        private System.Windows.Forms.TextBox textBox_DEP;
        private System.Windows.Forms.TextBox textBox_CIUDAD;
        private System.Windows.Forms.Button Registrar;
    }
}