﻿namespace Minimarket
{
    partial class UPD_Marketin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox_NIT = new System.Windows.Forms.TextBox();
            this.textBox_RZ = new System.Windows.Forms.TextBox();
            this.textBox_TEL = new System.Windows.Forms.TextBox();
            this.textBox_NOM = new System.Windows.Forms.TextBox();
            this.textBox_CIUDAD = new System.Windows.Forms.TextBox();
            this.textBox_DEP = new System.Windows.Forms.TextBox();
            this.textBox_EMAIL = new System.Windows.Forms.TextBox();
            this.textBox_SWEB = new System.Windows.Forms.TextBox();
            this.textBox_FA = new System.Windows.Forms.TextBox();
            this.textBox_WHA = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ACTUALIZAR = new System.Windows.Forms.Button();
            this.ENVIAR = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bernard MT Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(101, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 36);
            this.label1.TabIndex = 0;
            this.label1.Text = "NIT :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bernard MT Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(101, 121);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(184, 36);
            this.label2.TabIndex = 1;
            this.label2.Text = "RAZON SOCIAL :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bernard MT Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(101, 188);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(139, 36);
            this.label3.TabIndex = 2;
            this.label3.Text = "TELEFONO :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bernard MT Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(101, 250);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(186, 36);
            this.label4.TabIndex = 3;
            this.label4.Text = "NOMECLATURA :";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bernard MT Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(101, 309);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 36);
            this.label5.TabIndex = 4;
            this.label5.Text = "CIUDAD :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Bernard MT Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(101, 367);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(207, 36);
            this.label6.TabIndex = 5;
            this.label6.Text = "DEPARTAMENTO :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Bernard MT Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(101, 432);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(119, 36);
            this.label7.TabIndex = 6;
            this.label7.Text = "CORREO :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Bernard MT Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(101, 494);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(146, 36);
            this.label8.TabIndex = 7;
            this.label8.Text = "SITIO WEB :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Bernard MT Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(101, 548);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(145, 36);
            this.label9.TabIndex = 8;
            this.label9.Text = "FACEBOOK :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Bernard MT Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(101, 608);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(154, 36);
            this.label10.TabIndex = 9;
            this.label10.Text = "WHATSAPP :";
            // 
            // textBox_NIT
            // 
            this.textBox_NIT.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox_NIT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_NIT.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_NIT.Location = new System.Drawing.Point(424, 38);
            this.textBox_NIT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_NIT.Name = "textBox_NIT";
            this.textBox_NIT.Size = new System.Drawing.Size(415, 47);
            this.textBox_NIT.TabIndex = 10;
            // 
            // textBox_RZ
            // 
            this.textBox_RZ.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox_RZ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_RZ.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_RZ.Location = new System.Drawing.Point(424, 103);
            this.textBox_RZ.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_RZ.Name = "textBox_RZ";
            this.textBox_RZ.Size = new System.Drawing.Size(415, 47);
            this.textBox_RZ.TabIndex = 11;
            // 
            // textBox_TEL
            // 
            this.textBox_TEL.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox_TEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_TEL.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_TEL.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox_TEL.Location = new System.Drawing.Point(424, 171);
            this.textBox_TEL.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_TEL.Name = "textBox_TEL";
            this.textBox_TEL.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_TEL.Size = new System.Drawing.Size(415, 47);
            this.textBox_TEL.TabIndex = 12;
            // 
            // textBox_NOM
            // 
            this.textBox_NOM.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox_NOM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_NOM.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_NOM.Location = new System.Drawing.Point(424, 233);
            this.textBox_NOM.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_NOM.Name = "textBox_NOM";
            this.textBox_NOM.Size = new System.Drawing.Size(415, 47);
            this.textBox_NOM.TabIndex = 13;
            // 
            // textBox_CIUDAD
            // 
            this.textBox_CIUDAD.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox_CIUDAD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_CIUDAD.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_CIUDAD.Location = new System.Drawing.Point(424, 292);
            this.textBox_CIUDAD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_CIUDAD.Name = "textBox_CIUDAD";
            this.textBox_CIUDAD.Size = new System.Drawing.Size(415, 47);
            this.textBox_CIUDAD.TabIndex = 14;
            // 
            // textBox_DEP
            // 
            this.textBox_DEP.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox_DEP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_DEP.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_DEP.Location = new System.Drawing.Point(424, 350);
            this.textBox_DEP.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_DEP.Name = "textBox_DEP";
            this.textBox_DEP.Size = new System.Drawing.Size(415, 47);
            this.textBox_DEP.TabIndex = 15;
            // 
            // textBox_EMAIL
            // 
            this.textBox_EMAIL.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox_EMAIL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_EMAIL.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_EMAIL.Location = new System.Drawing.Point(424, 415);
            this.textBox_EMAIL.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_EMAIL.Name = "textBox_EMAIL";
            this.textBox_EMAIL.Size = new System.Drawing.Size(415, 47);
            this.textBox_EMAIL.TabIndex = 16;
            // 
            // textBox_SWEB
            // 
            this.textBox_SWEB.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox_SWEB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_SWEB.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SWEB.Location = new System.Drawing.Point(424, 476);
            this.textBox_SWEB.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_SWEB.Name = "textBox_SWEB";
            this.textBox_SWEB.Size = new System.Drawing.Size(415, 47);
            this.textBox_SWEB.TabIndex = 17;
            // 
            // textBox_FA
            // 
            this.textBox_FA.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox_FA.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_FA.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_FA.Location = new System.Drawing.Point(424, 530);
            this.textBox_FA.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_FA.Name = "textBox_FA";
            this.textBox_FA.Size = new System.Drawing.Size(415, 47);
            this.textBox_FA.TabIndex = 18;
            // 
            // textBox_WHA
            // 
            this.textBox_WHA.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox_WHA.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_WHA.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_WHA.Location = new System.Drawing.Point(424, 591);
            this.textBox_WHA.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_WHA.Name = "textBox_WHA";
            this.textBox_WHA.Size = new System.Drawing.Size(415, 47);
            this.textBox_WHA.TabIndex = 19;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox_NIT);
            this.groupBox1.Controls.Add(this.textBox_RZ);
            this.groupBox1.Controls.Add(this.textBox_WHA);
            this.groupBox1.Controls.Add(this.textBox_TEL);
            this.groupBox1.Controls.Add(this.textBox_FA);
            this.groupBox1.Controls.Add(this.textBox_NOM);
            this.groupBox1.Controls.Add(this.textBox_SWEB);
            this.groupBox1.Controls.Add(this.textBox_CIUDAD);
            this.groupBox1.Controls.Add(this.textBox_EMAIL);
            this.groupBox1.Controls.Add(this.textBox_DEP);
            this.groupBox1.Location = new System.Drawing.Point(43, 12);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(941, 690);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // ACTUALIZAR
            // 
            this.ACTUALIZAR.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ACTUALIZAR.Location = new System.Drawing.Point(1044, 416);
            this.ACTUALIZAR.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ACTUALIZAR.Name = "ACTUALIZAR";
            this.ACTUALIZAR.Size = new System.Drawing.Size(196, 66);
            this.ACTUALIZAR.TabIndex = 21;
            this.ACTUALIZAR.Text = "ACTUALIZAR";
            this.ACTUALIZAR.UseVisualStyleBackColor = true;
            this.ACTUALIZAR.Click += new System.EventHandler(this.button1_Click);
            // 
            // ENVIAR
            // 
            this.ENVIAR.Font = new System.Drawing.Font("Bernard MT Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ENVIAR.Location = new System.Drawing.Point(1336, 416);
            this.ENVIAR.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ENVIAR.Name = "ENVIAR";
            this.ENVIAR.Size = new System.Drawing.Size(196, 66);
            this.ENVIAR.TabIndex = 22;
            this.ENVIAR.Text = "ENVIAR";
            this.ENVIAR.UseVisualStyleBackColor = true;
            this.ENVIAR.Click += new System.EventHandler(this.button2_Click);
            // 
            // UPD_Marketin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1632, 812);
            this.Controls.Add(this.ENVIAR);
            this.Controls.Add(this.ACTUALIZAR);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "UPD_Marketin";
            this.Text = "UPD_Marketin";
            this.Load += new System.EventHandler(this.UPD_Marketin_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox_NIT;
        private System.Windows.Forms.TextBox textBox_RZ;
        private System.Windows.Forms.TextBox textBox_TEL;
        private System.Windows.Forms.TextBox textBox_NOM;
        private System.Windows.Forms.TextBox textBox_CIUDAD;
        private System.Windows.Forms.TextBox textBox_DEP;
        private System.Windows.Forms.TextBox textBox_EMAIL;
        private System.Windows.Forms.TextBox textBox_SWEB;
        private System.Windows.Forms.TextBox textBox_FA;
        private System.Windows.Forms.TextBox textBox_WHA;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button ACTUALIZAR;
        private System.Windows.Forms.Button ENVIAR;
    }
}