﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CL_CapaEntidades
{
    public class Proveedor
    {


        public string Id { get; set; }
        public string Nit { get; set; }
        public string RazonSocial { get; set; }
        public string Telefono { get; set; }
        public string Correo { get; set; }
        public string Nomeclaturas { get; set; }
        public string Ciudad { get; set; }
        public string Departamento { get; set; }
        
        
    }
}
