﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CL_CapaEntidades
{
    public class Market
    {
        public int Idmarket { get; set; }
        public string Nit { get; set; }
        public string RazonSocial { get; set; }
       
        public string Telefono { get; set; }
        public string Nomeclatura { get; set; }
        public string Ciudad { get; set; }
        public string Departamento { get; set; }
        public string Correo { get; set; }
        public string SitionWeb { get; set; }
        public string Facebook { get; set; }
        public string Whastapp { get; set; }
    }
}
